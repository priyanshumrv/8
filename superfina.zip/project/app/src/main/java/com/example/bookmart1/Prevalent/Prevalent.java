package com.example.bookmart1.Prevalent;

import com.example.bookmart1.Model.Users;

public class Prevalent {

    public static Users CurrentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
